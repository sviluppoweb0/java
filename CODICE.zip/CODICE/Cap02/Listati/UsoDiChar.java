package com.pellegrinoprincipe;

public class UsoDiChar
{
    public static void main(String[] args)
    {
        char ch = 82;
        System.out.println(ch); // stampa R
        ch++;                   // sposta al carattere successivo
        System.out.println(ch); // stampa S
    }
}
