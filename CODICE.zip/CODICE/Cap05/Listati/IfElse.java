package com.pellegrinoprincipe;

public class IfElse
{
    public static void main(String[] args)
    {
        int a = 5;

        if (a >= 10)
            System.out.println("a >= 10"); // eseguita se a è maggiore o uguale a 10
        else
            System.out.println("a < 10"); // eseguita in caso contrario
    }
}
