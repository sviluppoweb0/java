package com.pellegrinoprincipe;

public class For
{
    public static void main(String[] args)
    {
        System.out.print("a = ");
        for (int a = 8; a >= 0; a--) // finché a >= 0 cicliamo...
            System.out.print(a + " ");
    }
}
