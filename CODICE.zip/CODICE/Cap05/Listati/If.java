package com.pellegrinoprincipe;

public class If
{
    public static void main(String[] args)
    {
        int a = -1;

        // a e' minore di 10?
        if (a < 10)
            System.out.println("a < 10");
    }
}
