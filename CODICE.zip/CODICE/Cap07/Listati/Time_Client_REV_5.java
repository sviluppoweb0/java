package com.pellegrinoprincipe;

public class Time_Client_REV_5
{
    public static void main(String[] args)
    {
        Time_REV_5 t = new Time_REV_5(new Time_REV_5(20, 0, 0));
        System.out.println(t);
    }
}
