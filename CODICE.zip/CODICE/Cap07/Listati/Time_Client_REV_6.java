package com.pellegrinoprincipe;

public class Time_Client_REV_6
{
    public static void main(String[] args)
    {
        Time_REV_6 time1 = new Time_REV_6();
        System.out.println(time1.setOra(18).setMinuti(30).setSecondi(20)); // imposto a cascata l'orario
    }
}
