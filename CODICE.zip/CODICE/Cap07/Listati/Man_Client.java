package com.pellegrinoprincipe;

public class Man_Client
{
    public static void main(String[] args)
    {
        Man a_man = new Man("Principe", "Pellegrino", 8);
        System.out.println(a_man);
    }
}
